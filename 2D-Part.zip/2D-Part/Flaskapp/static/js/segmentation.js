// segmentation.js
document.querySelector("#formFileLg").addEventListener("change",(e)=>{
    if(window.File && window.FileReader && window.FileList && window.Blob){
        const Files =e.target.files;
        // console.log(Files)
        const output = document.querySelector("#result");
        for(let i = 0;i < Files.length;i++){
            if(!Files[i].type.match("image")) continue;
            const picReader = new FileReader();
            picReader.addEventListener("load",function(event){
                const picFile = event.target;
                const div = document.createElement("div");
                div.innerHTML = `<img class="thumbnail" src="${picFile.result}" title="${picFile.name}"/>`;
                output.appendChild(div);
            })
            // console.log(picReader);
            picReader.readAsDataURL(Files[i]);
        }
        
    }else{alert("your browser does not support the File API ")}
})