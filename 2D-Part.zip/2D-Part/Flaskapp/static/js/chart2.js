const ctx2 = document.getElementById('pie').getContext('2d');

new Chart(ctx2, {
    type: 'pie',
    data: {
        labels: [
            'Gliomas',
            'Meningiomas',
            'Pituitary tumors',
            'Pineal tumors',
            'Germ cell tumors',
            'Embryonal tumors'
        ],
        datasets: [{
        label: 'The Distribution of Tumor Types',
        data: [80, 50, 100, 150, 200, 350],
        backgroundColor: [
            'rgb(255, 99, 132)',
            'rgb(54, 162, 235)',
            'rgb(255, 205, 86)',
            'rgb(128,0,128)',
            'rgb(0,128,128)',
            'rgb(250,235,215)',
        ],
        hoverOffset: 4
        }]
    }
});