window.onload = function () {
    var chart = new CanvasJS.Chart("chartContainer",
    {
    title:{
        text: "the percentages of brain tumors:",
        fontFamily: "Impact",
        fontWeight: "normal"
    },

    legend:{
        verticalAlign: "bottom",
        horizontalAlign: "center"
    },
    data: [
    {
        //startAngle: 45,
    indexLabelFontSize: 25,
    indexLabelFontFamily: "Garamond",
    indexLabelFontColor: "rgb(21, 20, 20)",
    indexLabelLineColor: "darkgrey",
    indexLabelPlacement: "outside",
    type: "doughnut",
    showInLegend: true,
    dataPoints: [
    {  y: 53.37, legendText:"Gliomas 53%", indexLabel: "Gliomas 53%" },
    {  y: 35.0, legendText:"Meningiomas 35%", indexLabel: "Meningiomas 35%" },
    {  y: 7, legendText:"Pituitary 7%", indexLabel: "Pituitary 7%" },
    {  y: 2, legendText:"Germ cell tumorss 2%", indexLabel: "Germ cell tumors 2%" },
    {  y: 5, legendText:"Pineal tumors 5%", indexLabel: "Pineal tumors 5%" }
    ]
    }
    ]
});

    chart.render();
}