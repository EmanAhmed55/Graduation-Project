import tkinter as tk
from PIL import Image, ImageTk

def open_app1():
    # Import your main app code here
    window.destroy()

    import GUI_by_case


def open_app2():
    # Import your main app code here
    window.destroy()

    import GUI_by_path

# Create the start window
bg_image = Image.open("back1.png")
bg_width, bg_height = bg_image.size

# Create the main window
window = tk.Tk()
window.title("start")

# Set the window size to match the background image
window.geometry(f"{bg_width}x{bg_height}")

# Create a label with the background image
bg_photo = ImageTk.PhotoImage(bg_image)
bg_label = tk.Label(window, image=bg_photo)
bg_label.place(x=0, y=0)

# Create a label with instructions for the user
instruction_label = tk.Label(window, text="Welcom to Vita ", fg="#eebad4", font=("Helvetica", 24, "bold"))
instruction_label.place(relx=0.5, rely=0.4, anchor="center")

# Create a button to open the app
open_button1= tk.Button(window, text="segmentation by case", command=open_app1, bg="#a86bf1", fg="white",font=("Helvetica", 20, "bold"))
open_button1.place(relx=0.5, rely=0.5, anchor="center")
open_button2= tk.Button(window, text="segmentation by path", command=open_app2, bg="#a86bf1", fg="white",font=("Helvetica", 20, "bold"))
open_button2.place(relx=0.5, rely=0.58, anchor="center")

# Start the main event loop
window.mainloop()